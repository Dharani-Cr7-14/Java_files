package trees;

import java.util.Stack;

class node{
	char val;
	node left;
	node right;
	
	node(char val)
	{
		this.val=val;
		 left = right = null;
	}
}

public class expression_rees 
{
	static boolean isoperator(char ch)
	{
		if(ch=='+' || ch== '-' || ch=='*' || ch=='/')
		{
			return true;
		
		}
		else 
		{
			return false;
		}
	}
	
	static node expression(String postfix)
	{
		Stack<node> st=new Stack<>();
		node t1,t2,temp;
		for(int i=0;i<postfix.length();i++)
		{
			if(!isoperator(postfix.charAt(i)))
			{
				temp=new node(postfix.charAt(i));
				st.push(temp);
				
			}
			else
			{
				temp=new node(postfix.charAt(i));
				t1=st.pop();
				t2=st.pop();
				
				temp.left=t2;
				temp.right=t1;
				
				st.push(temp);
			}
		}
		temp=st.pop();
		return temp;
	}
	
	static void inorder(node root)
	{
		if(root==null)
		{
			return ;
		}
		inorder(root.left);
		System.out.print(root.val);
		inorder(root.right);
		
	}

	public static void main(String[] args)
	{
		String postfix="ABC*D+-";
		 node r=expression(postfix);
		 inorder(r);
		
	}
}
