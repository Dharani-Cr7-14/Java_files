package linked_list;

class link
{
	 node head;
	 node tail;
	 
	 
	
	 void insert(int val)
	 {
		 if(tail==null)
		 {
			 tail=head;
		 }
		 node newnode=new node(val);
		 
		 newnode.next=head;
		 head=newnode;
		
	 }
	 
	 void display()
	 {
		 node temp=head;
		 
		 while(temp!=null)
		 {
			 System.out.println(temp.val);
			 temp=temp.next;
		 }
	 }
	 void last(int val)
	 {
	     
	     node newnode=new node(val);
	     node temp=head;
	     while(temp.next!=null)
	     {
	    	 temp=temp.next;
	     }
	     temp.next=newnode;
	  
	     
	 }
	 void pos(int val ,int pos)
	 {
		 node temp=head;
		 node newnode=new node(val);
		 
		 for(int i=0;i<pos-1;i++)
		 {
			 temp=temp.next;
		 }
		 newnode.next=temp.next;
		 temp.next=newnode;
	 }
	 void delete(int pos)
	 {
		 node temp=head;
		 node pre=null;
		 for(int i=1;i<=pos;i++)
		 {
			 pre=temp;
			 temp=temp.next;
		 }
		 pre.next=temp.next;
	 }
	 void D_first()
	 {
		 head=head.next;
	 }
	 
	 void reversal()
	 {
		 
		 node current =head;
		 node next=current.next;
		 node pre=null;
		 
		 
		 while(current!=null)
		 {
			 next=current.next;
			 current.next=pre;
			 
			 pre=current;
			 current=next;
		 }
		 head=pre;
		 
	 }

	 
	 
	 
	 
	 class node
	 {
		 int val;
		 node next;
		 
		 node(int val)
		 {
			 this.val=val;
		 }
	 }
	
}


	



public class perfect_linked_list
{
	public static void main(String args[])
	{
		link list=new link();
		list.insert(1);
		list.insert(2);
		list.insert(3);
		list.display();
		System.out.println("\n");
        list.last(5);
        list.display();
	/*	System.out.println("\n");

        list.pos(2111,2 );
        list.display();
		System.out.println("\n");

        list.delete(4);
       // list.D_first();
        list.display();
       */ 
        list.reversal();
		System.out.println("\n");
		list.display();

	}
}
