package linked_list;

class ll
{
	node head;
	node tail;
	int size=0;
	
	
	void insert(int val)
	{
		
		node newnode=new node(val);
		newnode.next=head;
		head=newnode;
	}
	void display()
	{
		node temp=head;
		while(tail!=null)
		{
			System.out.print(temp.val);
			temp=temp.next;
		}
		size++;
	}
	
	class node
	{
		int val;
		node next;
		
		node(int val)
		{
			this.val=val;
		}
		
		
		
		
	}



	
}

public class inserting 
{
	public static void main(String args[])
	{
		ll obj=new ll();
		obj.insert(22);
		obj.display();
		
	}

}
