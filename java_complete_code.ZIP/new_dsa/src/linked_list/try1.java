package linked_list;

class lle
{
	node head;
	node tail;
	int size=0;
	
	
	void insert(int value)
	{
		node newnode=new node(value);
		if(size==0)
		{
			head=newnode;
			
		}
		else
		{
			newnode.next=head;
			head=newnode;
		}
		size++;	
	}
	
	
	void insert_last(int pos,int value)
	{
		node newnode=new node(value);
		node temp=head;
		for(int i=1;i<pos-1;i++)
		{
			temp=temp.next;
		}
		temp.next=newnode;
		
		size++;

	}
	
	void display()
	{
		node temp=head;
		for(int i=0;i<size;i++)
		{
			System.out.println(temp.value);
			temp=temp.next;
		}
	}
	
	
	
	
	
	
	class node
	{
		int value;
		node next;
		
		node(int value)
		{
			this.value=value;
		}
	}
}


public class try1 
{
  public static void main(String args[])
  {
	  lle li=new lle();
	  li.insert(2);
	  li.insert(3);
	  li.insert(4);
	 
	
	  li.display();
	  
	  li.insert_last(8);
	  li.display();
	 
	  



  }
}
