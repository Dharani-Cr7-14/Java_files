package heap_Heapsort;
import java.util.*;

class heap
{
	ArrayList<Integer> list=new ArrayList<Integer>();
	
	void swap(int first,int second)
	{
		int temp=list.get(first);
		list.set(first,list.get(second));
		list.set(second,temp);
				
	}
	int parent(int index)
	{
		return (index-1)/2;
	}
	
	int left(int index) 
	{
		return (index*2)+1;
	}
	
	int right(int index)
	{
		return (index*2)+2;
	}
	
	void insert(int value)
	{
		list.add(value);
		upheap(list.size()-1);
	}
	
	void upheap(int index)
	{
		
		int p=parent(index);
		if(list.get(index).compareTo(list.get(p))<0)
		{
			swap(index,p);
			upheap(p);
		}
	return ;
	}
	
	int remove()
	{
		
		int temp=list.get(0);
		
		int last=list.remove(list.size()-1);
		if(!list.isEmpty())
		{
			list.set(0,last);
			downheap(0);
		}
		
		return temp;
	}
	void downheap(int index)
	{
		int min=index;
		int left=left(index);
		int right=right(index);
		
		if(left< list.size()&& list.get(min).compareTo(list.get(left))>0 )
		{
			min=left;
		}
		if(right<list.size() && list.get(min).compareTo(list.get(right))>0)
		{
			min=right;
		}
		if(min!=index)
		{
			swap(min,index);
			downheap(min);
		}
	}
		
	ArrayList<Integer> heapSort()
	{
	    ArrayList<Integer> data = new ArrayList<>();
	     while(!list.isEmpty())
	      {
		    data.add(this.remove());
	      }
	      	return data;
	} 
	
	
	
}

public class insert_delete_in_heap 
{
  public static void main(String args[])
  {
	  heap li=new heap();
			  {
		       li.insert(3);
		       li.insert(6);
		       li.insert(1);
		       li.insert(2);

		       li.insert(8);
		       
		       
		       System.out.println(li.remove());
		      
		       
		       
		       ArrayList list = li.heapSort();
		       System.out.println(list);
			  }
	
  }


}

