package Searching_Sorting;

import java.util.Arrays;

class selection
{
   void select(int arr[])
  {
	  for(int i=0;i<arr.length;i++)
	  {
		int   mindex=i;
		  for(int j=i+1;j<arr.length;j++)
		  {
			  if (arr[j]<arr[mindex])
			  {
				  mindex=j;
			  }
		  }
		  int temp=arr[i];
		  arr[i]=arr[mindex];
		  arr[mindex]=temp;
	  }
  }
}



public class selection_demo 
{
  public static void main (String args[])
  {
	  selection sel=new selection();
	  int arr[]= {3,1,5,6,7,9,4,2};
	  sel.select(arr);
	  System.out.print(Arrays.toString(arr));
  }
}
