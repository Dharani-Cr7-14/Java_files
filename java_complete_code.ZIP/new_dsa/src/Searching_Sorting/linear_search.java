package Searching_Sorting;

import java.util.Arrays;

class linear
{
	static int search(int arr[],int target) // 1D linear search
	{
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==target)
			{
				return i;
			}
		}return -1;
	}
	
	  
	static int search(String arr,char target)   // character search
	{
		for(int i=0;i<arr.length();i++)
		{
		  if(arr.charAt(i)==target)
		  {
			  return i;
		  }
		}return -1;
	}
	
	
	
	static int[] search(int arr[][],int target)   // 2D linear search
	{
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr[i].length;j++)
			{
				if(arr[i][j]==target)
				{
					return new int[]  {i,j};
				}
			}

			
		}return new int[] {-1,-1};
	}
	
	static int max(int arr[])  // max value and min value
	{
		int min=arr[0];
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]>min)
			{
				min=arr[i];
				
			}
		}return min;
	}
	
	
	static int count(String arr,char target)    // number of occurence a character
	{
		int count=0;
		for(int i=0;i<arr.length();i++)
		{
			if(arr.charAt(i)==target)
			{
				count+=1;
			}
		}return count;
		
	}
	static int four(int arr[])     // four digit count
	{
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i] >=999 && arr[i]<9999)
			{
				return arr[i];
			}
		}return -1;
	}

	
}






public class linear_search 
{
  public static void main(String args[])
  {
	  linear li=new linear();
	  
	  int arr[]= {1,2,3,4,5,6};
	  System.out.println(li.search(arr, 4));
	  
	  String word="dharaniiiiiiiii";
	  System.out.println(li.search(word, 'd'));
	  
	  int arr1[][]= 
		  {
				  { 1,2,3},
				  {4,5,6},
				  {7,8,9}
		  };
	  int ans[]=linear.search(arr1, 1);
	  System.out.println(Arrays.toString(ans));
	  
	  System.out.println(linear.max(arr));

	  System.out.println(linear.count(word, 'i'));
	  System.out.println(linear.four(arr)); 

	  
	  
  }
}
