package Searching_Sorting;

public class missing_ele
{
	
	    public static void main(String[] args) 
	    {
	        int sum=0;
	       for(int i=1;i<=2;i++)
	       {
	            sum+=i;
	            
	       }
	       System.out.println(sum);
	       
	       int sum2=0;
	       int arr[]={1};
	       for(int i=0;i<arr.length;i++)
	       {
	          sum2+=arr[i]; 
	         

	        }
	       System.out.println(sum2);
	       int m=sum-sum2;
	       System.out.println("missing"+m);
	}
	   

	

}
