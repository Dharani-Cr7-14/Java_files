package Searching_Sorting;

import java.util.Arrays;

class insert
{
	
	
	 static  public void insertion(int arr[])
	  {
		  for(int i=1;i<arr.length;i++)
		  {
			  int key=arr[i];
			  int j;
			  for( j=i-1;j>=0 && arr[j]>key;j--)
			  {
				  arr[j+1]=arr[j];
			  }
			  
			  arr[j+1]=key;
		  }
	  }


	
}

public class insertion_sort 

{
  public static void main(String args[])
  {
	  int arr[]= {2,5,1,99,3,5,6,3,4};
	  insert.insertion(arr);
	  System.out.println(Arrays.toString(arr));
	  
  }
}
