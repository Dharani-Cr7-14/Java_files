package doubly_linked;


class doubly
{
	node head;
	node tail;
	int size=0;
	
	
	
	void insert(int val)
	{
		node newnode=new node(val);
		
		if(head==null)
		{
			head=newnode;
			tail=newnode;        //node newnode=new node(val);
			                    //   newnode.next=head;
			                      // head=newnode;
		}
		
		else
		{
			head.pre=newnode;
			newnode.next=head;
			head=newnode;
		}
		size++;
	}
	
	void pos(int pos,int val)
	{
	  
		node newnode=new node(val);
		
		node temp=head;
		
		for(int i=1;i<pos;i++)
		{
			temp=temp.next;
			
		}
		newnode.next=temp.next;
		
		
		temp.next=newnode;
		temp.next.pre=newnode;
		newnode.pre=temp; 
		size++;
		
		
		
	}
	
	void last(int val)
	{
		node newnode=new node(val);
		
		node temp=head;
		
		for(int i=1;i<size;i++)
		{
			temp=temp.next;
		}
		newnode.pre=temp;
		temp.next=newnode;
		
		//newnode.next=null;
		size++;
		
		
			}
	
	
	
	void deleteLast()
	{
        node temp=head;
		
		for(int i=1;i<size;i++)
		{
			temp=temp.next;
			
		}
		temp.next=null;
		size--;
	}
	
	
	void deletePos(int pos)
	{
		
		node prev=null;
		node temp=head;
		for(int i=1;i<=pos;i++)
		{
			prev=temp;
			temp=temp.next;
		}
		prev.next=temp.next;
		temp.next.pre=prev;
		size--;
		
		
		
	}
	
	void deletefirst()
	{
		head=head.next;
		size--; 
	}
	
	
	void display()
	{
		node temp = head;
		while(temp!=null)
		{
			System.out.println(temp.val);
			temp=temp.next;
		}
	}
	void displayRev()
	{
	
		node temp=head;
		while(temp!=null)
		{
			temp=temp.next;
			temp.next=pre;
			
			
		}
		
		
		
		
		
		
		node temp=head;
		while(temp!=null)
		{
			temp=temp.next;
		}
		node temp = tail;
		while(temp!=null)
		{
			System.out.println(temp.val);
			temp=temp.pre;
		}
	}
	
	
	
	
	
	
	class node
	{
		int val;
		node next;
		node pre;
		
		
		node(int val)
		{
			this.val=val;
			next=null;
			pre=null;
		}
	}
}

public class operation_doubly 
{
	public static void main(String args[])
	{
		doubly l=new doubly();
		l.insert(2);
		l.insert(3);
		l.insert(4);
		l.display();
		System.out.println("\n");
		l.last(77);
		l.display();
		l.deletePos(2);
		l.display();

		l.displayRev();

	/*	l.pos(3,55);
		l.display();
		System.out.println("\n");

		
		System.out.println();
		l.deletefirst();
		l.display();
*/

	}

  }
