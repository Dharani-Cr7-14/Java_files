package binary_search_tree;
import java.util.*;

class binary_search_tree
{
	node root;
	binary_search_tree(int val)
	{
		root=new node(val);
	}
	binary_search_tree()
	{
		root=null;
	}
	class node{
		int val;
		node left;
		node right;
		node(int val)
		{
			this.val=val;
		}
	}
	
	void insert(int val)
	{
		insert(root,val);
	}
	node insert(node root,int val)
	{
		if(root==null)
		{
			return new node(val);
			
		}
		if(val<root.val)
		{
			root.left=insert(root.left,val);
	    
		}
		else
		{
			root.right=insert(root.right,val);
		}
		return root;
	}
	
	void preorder(node root)     
	{
		if(root!=null)
		{
			System.out.println(root.val +"");
			preorder(root.left);
			preorder(root.right);
		}
	}
	void inorder(node root)    // same as post order
	{
		if(root!=null)
		{
			inorder(root.left);
			System.out.println(root.val+ "");
			inorder(root.right);
		}
	}
	node search(node root,int val)
	{
		if(root==null || root.val==val)
		{
			return root;
		}
		if(val<root.val)
		{
			return search(root.left,val);
		}
		
	
		return search(root.right,val);
	
	}
	
	node delete(node root,int val)
	{
		if(val<root.val)
		{
			root.left=delete(root.left,val);
		}
		else if(val>root.val)
		{
			root.right=delete(root.right,val);
		}
		else
		{
			if(root.left==null)
			{
				return root.right;
			}
			else if(root.right==null)
			{
				return root.left;
			}
		}return root;
	}
	void min(node root)
	{
		int min_val=root.val;
		while(root.left !=null)
		{
			min_val=root.left.val;
			root=root.left;
		}
		System.out.println( root.val);
	}
}

public class insert 
{
	public static void main(String args[])
	   {
		Scanner scan=new Scanner(System.in);
		binary_search_tree obj=new binary_search_tree(scan.nextInt());
		obj.insert(6);
		obj.insert(3);
		obj.insert(7);
		obj.insert(9);
		obj.inorder(obj.root);
		if(obj.search(obj.root,9)==null)
		{
			System.out.println("not found");
		}
		else
		{
			System.out.println("found");

		}
		 //obj.delete(obj.root, 3);
		obj.inorder(obj.root);
        obj.min(obj.root);


	  }
	
}
