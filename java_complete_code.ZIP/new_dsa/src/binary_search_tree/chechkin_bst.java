package binary_search_tree;

class binary_searchtest
{
	node root;
	binary_searchtest(int val)
	{
		root=new node(val);
	}
	binary_searchtest()
	{
		root=null;
	}
 
	class node
	{
	  int val;
	  node left;
	  node rigth;
	  node(int val)
	  {
		  this.val=val;
	  }
	}
	
	void insert(int val)
	{
		insert(root,val);
	}
	
	node insert(node root,int val)
	{
		if(root==null)
		{
			return new node (val);
		}
		else if(val<root.val)
		{
			root.left=insert(root.left,val);
		}
		else
		{
			root.rigth=insert(root.rigth,val);
		}
		
		return root;
		
	}
	
	void display(node root)
	{
		if(root!=null)
		{
			
			display(root.left);
			System.out.println(root.val + " ");
			display(root.rigth);
		}
	}
	
	node search(node root, int val)
	{
		if(root==null || root.val== val)
		{
			return root;
		}
		else if(val<root.val)
		{
			return search(root.left,val);
		}
	return search(root.rigth,val);
	}
	
	node delete(node root,int val)
	{
		if(val<root.val)
		{
			root.left=delete(root.left,val);
		}
		if(val>root.val)
		{
			root.rigth=delete(root.rigth,val);
		}
		else
		{
			if(root.left==null)
			{
				return root.rigth;
			}
			else if (root.rigth==null)
			{
				return root.left;
			}
		//	root.val=min(root.rigth);
		//	root.rigth=delete(root.rigth,root.val);
		}
		return root;
	}
	
	int min(node root)
	{
		int min_val=root.val;
		while(root.left!=null)
		{
			min_val=root.left.val;
			root=root.left;
		}
		return min_val;
	}
}



public class chechkin_bst 
{
 public static void main(String args[])
 {
	 binary_searchtest x=new binary_searchtest(25);
	 x.insert(3);
	 x.insert(7);
	 x.insert(9);
	 x.insert(11);
	 x.insert(4);
	 x.insert(8);
	 x.insert(2);
	 
	 x.display(x.root);
	 if(x.search(x.root,25)==null)
	 {
		 System.out.println("not found");
	 }
	 else
	 {
		 System.out.println("found");

	 }
	 x.delete(x.root, 3);
	 x.display(x.root);

 }
}
