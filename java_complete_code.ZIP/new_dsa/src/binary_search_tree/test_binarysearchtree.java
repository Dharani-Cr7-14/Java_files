package binary_search_tree;

class binary_searchtree
{
	node root;
	
	binary_searchtree(int val)
	{
		root=new node(val);
	}
	
	binary_searchtree()
	{
		root=null;
	}
	
	class node
	{
		int val;
		node left;
		node right;
		node(int val)
		{
			this.val=val;
		}
	}
	
    void insert(int val)
	{
		insert(root,val);
	}
	
	node insert(node root,int val)
	{
		if(root==null)
		{
			return new node(val);
		}
		if(val<root.val)
		{
			root.left=insert(root.left,val);
		}
		else
		{
			root.right=insert(root.right,val);
		}
		return root;
	}
	
	node search(node root,int val)
	{
		if(root==null || root.val==val)
		{
			return root;
		}
		if(val<root.val)
		{
			return search(root.left,val);
		}
		
	
		return search(root.right,val);
	
	}
	
	
	void inorder(node root)
	{
		if(root!=null)
		{
			inorder(root.left);
			System.out.println(root.val);
			inorder(root.right);
		}
	}
	
	
}

public class test_binarysearchtree 
{
	public static void main(String args[])
	{
		binary_searchtree li=new binary_searchtree(50);
		li.insert(3);
		li.insert(2);
		li.insert(37);
		li.insert(7);
		li.insert(44);
		li.insert(9);
		li.insert(2);
		li.inorder(li.root);
		if(li.search(li.root,37)==null)
		{
			System.out.println("not found");
		}
		else
		{
			System.out.println("found");

		}
		
		
		}
	
}
