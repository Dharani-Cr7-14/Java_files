package circular_linked_list;


class circular
{
	
	node tail;
	int size=0;
	
	
	
	
	void insertAtBegin(int val)
	{
		node newnode=new node(val);
		if(tail==null)
		{
			newnode.next=newnode;

			tail=newnode;
			
		
		}
		else
		{
			newnode.next=tail.next;
			tail.next=newnode;
		}
		size++;	
	}
	
	void insertAtEnd(int val)
	{
		
		node newnode=new node(val);
		newnode.next=tail.next;
		tail.next=newnode;
		tail=newnode;
		size++;
		
	}
	
	void delete(int pos)
	{
		node temp=tail.next;
		node pre=null;
		for(int i=0;i<pos;i++)
		{
			pre=temp;
			temp=temp.next;
		}
		pre.next=temp.next;
		size--;
		
		
		
	}
	void deleteAtlast()
	{
		node temp=tail.next;
		node pre=null;
		for(int i=1;i<size;i++)
		{
			pre=temp;
			temp=temp.next;
		}
		
		pre.next=temp.next;
		tail=pre;
		size--;
	}
	void deleteSingle()
	{
		if(tail.next==tail)
		{
			tail.next=null;
		}
		size--;
	}
	void deleteAtFirst()
	
	{
		
		tail.next=tail.next.next;
		size--;
	}
	
	
	void display()
	{
		node temp=tail.next;
		for(int i=1;i<size;i++)
		{
			System.out.println(temp.val);
			temp=temp.next;
			
		}
		System.out.println(tail.val);
		
		
		
		
	}
	class node
	{
		int val;
		node next;
		
		node(int val)
		{
			this.val=val;
		}
		
	}
}



public class circular_Operation 

{
	public static void main(String args[])
	{
		circular obj=new circular();
		obj.insertAtBegin(3);
		obj.insertAtBegin(4);
		obj.insertAtBegin(5);
		obj.insertAtBegin(6);
		obj.insertAtBegin(7);


		obj.display();
		System.out.println();
		
	/*	obj.insertAtEnd(7);
		obj.display();
		System.out.println(); */
      //  obj.delete(2);
      //  obj.display();
		System.out.println();
		System.out.println(obj.size);
		System.out.println();

		obj.deleteAtlast();
		obj.deleteAtlast();
		obj.display();
		System.out.println();

		System.out.println(obj.size);
		System.out.println();
		//obj.deleteSingle();
		obj.deleteAtFirst();
		obj.display();
		
		

		
	}

}
