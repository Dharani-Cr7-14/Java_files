package stack_Using_Arr;

class stack_ll
{
	node head;
	
	
	void push(int val)
	{
		node newnode =new node(val);
		newnode.next=head;
		head=newnode;
		
	}
	int pop()
	{
		int temp=head.val;
		head=head.next;
		return temp;
		
	}
	int peek()
	{
		return head.val;
	}
	
	
	
	class node
	{
		int val;
		node next;
		
		node(int val)
		{
			this.val=val;
		}
	}
}

public class Stack_linked_list 
{
	public static void main(String args[])
	{
	stack_ll obj=new stack_ll();
	obj.push(1);
	obj.push(2);
	obj.push(3);
	obj.push(4);
	obj.push(5);
	
	System.out.println(obj.pop());
	System.out.println(obj.pop());
	System.out.println(obj.pop());
	System.out.println();

	System.out.println(obj.peek());

}
}
