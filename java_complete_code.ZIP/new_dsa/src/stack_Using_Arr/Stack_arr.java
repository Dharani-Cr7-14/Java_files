package stack_Using_Arr;

class stack
{
	int arr[]=new int[10];
	int size;
	
	stack()
	{
		size=-1;
	}
	
	
	
	void push(int val)
	{
		arr[++size]=val;	
		
	}
	
	int pop()
	{
		return arr[size--];
	}
	
	int peek()
	{
		return arr[size];
	}
	

	
}

public class Stack_arr
{

	public static void main(String args[])
	{
		stack obj=new stack();
		obj.push(1);
		obj.push(2);
		obj.push(3);
		obj.push(4);
		obj.push(5);
		
		System.out.println(obj.pop());
		System.out.println(obj.pop());
		System.out.println(obj.pop());
		 
		System.out.println();
		System.out.println(obj.peek());
		System.out.println(obj.peek());

		
		

		
	}
}
