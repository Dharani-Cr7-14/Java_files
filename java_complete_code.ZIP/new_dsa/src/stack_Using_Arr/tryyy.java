package stack_Using_Arr;


class stack_ll
{
	node head;
	
	class node
	{
		int value;
		node next;
		
		
		node(int value)
		{
			this.value=value;
		}
	}
	void push(int value)
	{
		node newnode =new node(value);
		newnode.next=head;
		head=newnode;
	}
	
	int pop()
	{
		int  temp=head.value;
		return temp;
	}
	
}

public class tryyy {
	public static void main(String args[])
	{
	stack_ll obj=new stack_ll();
	obj.push(1);
	obj.push(2);
	obj.push(3);
	obj.push(4);
	obj.push(5);
	
	System.out.println(obj.pop());
	System.out.println(obj.pop());
	System.out.println(obj.pop());
	System.out.println();


}

}
