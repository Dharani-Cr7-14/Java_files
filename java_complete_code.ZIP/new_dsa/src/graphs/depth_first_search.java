package graphs;
import java.util.*;

class adjacen_list
{
	ArrayList<ArrayList<Integer>> adjlist=new ArrayList<> ();
	
	adjacen_list(int numvertex)
	{
		for(int i=0;i<numvertex;i++)
		{
			adjlist.add(new ArrayList<Integer>());
		}
	}
	
	void addedge(int v1,int v2)
	{
		adjlist.get(v1).add(v2);
	}
	
	void print()
	{
		for(int i=0;i<adjlist.size();i++)
		{
	     
	      for(int j=0;j<adjlist.get(i).size();j++)
	      {
		      System.out.println("vertex:"+i +  "edges" + adjlist.get(i).get(j));

	      }
		}
	}
	void dfs(int v)
	{
		boolean visited[]=new boolean[adjlist.size()];
		dfs2(v,visited);
	}
	void dfs2(int v,boolean visited[])
	{
		visited[v]=true;
		System.out.println(v);
		for(int i=0;i<adjlist.get(v).size();i++)
		{
			int av=adjlist.get(v).get(i);
			if(!visited[av])
			{
				dfs2(av,visited);
			}
		}
		
	}
	
	
}

public class depth_first_search 
{
  public static void main(String args[])
  {
	  adjacen_list x=new adjacen_list(5);
	  x.addedge(0,1);
	  x.addedge(2,3);
	  x.addedge(1,2);
	  x.addedge(3,4);
	  x.addedge(0,4);
      x.addedge(1, 4);
	  x.print();
	  x.dfs(0);

  }
}
