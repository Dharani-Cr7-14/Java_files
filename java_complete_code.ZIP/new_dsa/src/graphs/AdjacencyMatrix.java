package graphs;

public class AdjacencyMatrix {
    private int[][] matrix; // adjacency matrix
    private int numVertices; // number of vertices

    public AdjacencyMatrix(int numVertices) {
        this.numVertices = numVertices;
        matrix = new int[numVertices][numVertices]; // initialize matrix with zeros
    }

    public void addEdge(int v1, int v2) {
       
        matrix[v1][v2] = 1;
        matrix[v2][v1] = 1; // for undirected graph
    }

   

    public void printMatrix() {
        for (int i = 0; i < numVertices; i++) {
            for (int j = 0; j < numVertices; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        AdjacencyMatrix graph = new AdjacencyMatrix(5);
        graph.addEdge(1, 0);
        graph.addEdge(1, 2);
        graph.addEdge(1, 2);
        graph.addEdge(1, 0); // for undirected graph
        graph.addEdge(1, 3);

        graph.printMatrix();
    }
}
