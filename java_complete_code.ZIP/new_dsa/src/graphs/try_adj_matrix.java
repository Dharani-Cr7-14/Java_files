package graphs;

class adjacency_matrix
{
	int [][]matrix=new int [5][5];


	
	void  addedge(int v1,int v2)
	{
		matrix[v1][v2]=1;  // for directed graph this only
		matrix[v2][v1]=1;    // for undirected graph          
	}
	void print()
	{
		for(int i=0;i<matrix.length;i++)
		{
			for(int j=0;j<matrix.length;j++)
			{
				System.out.print(matrix[i][j]+" ");
			}
			System.out.println();

		}
	}
	
}

public class try_adj_matrix 
{
  public static void main (String args[])
  {
	  adjacency_matrix x=new adjacency_matrix();
	  x.addedge(1, 3);
	  x.addedge(0, 1);
	  x.addedge(2, 1);
	  x.print();

  }
  
}
