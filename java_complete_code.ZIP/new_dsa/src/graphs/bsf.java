package graphs;

import java.util.*;




class adjacenc_list
{
	ArrayList<ArrayList<Integer>> adjlist=new ArrayList<> ();
	
	adjacenc_list(int numvertex)
	{
		for(int i=0;i<numvertex;i++)
		{
			adjlist.add(new ArrayList<Integer>());
		}
	}
	
	void addedge(int v1,int v2)
	{
		adjlist.get(v1).add(v2);
	}
	
	void print()
	{
		for(int i=0;i<adjlist.size();i++)
		{
	     
	      for(int j=0;j<adjlist.get(i).size();j++)
	      {
		      System.out.println("vertex:"+i +  "edges" + adjlist.get(i).get(j));

	      }
		}
	}
	
	void bsf(int v)
	{
		
		boolean visited[]=new boolean[adjlist.size()];
		visited[v]=true;
		Queue<Integer> q=new LinkedList<>();
		q.add(v);
		while(q.size()!=0)
		{
			int  vertex=q.remove();
			System.out.println(vertex +"");
			for(int i=0;i<adjlist.get(vertex).size();i++)
			{
				int av=adjlist.get(vertex).get(i);
				if(!visited[av])
				{
					q.add(av);
					visited[av]=true;
				}
			}
			
		}
	}
	
	
}

public class bsf
{
  public static void main(String args[])
  {
	  adjacenc_list x=new adjacenc_list(70);
	  x.addedge(0, 1);
	  x.addedge(1, 4);
	  x.addedge(0, 3);
	  x.addedge(1, 3);
	  x.addedge(2, 4);
	  x.addedge(1, 2);
	 

	  x.print();
	  
	  x.bsf(0);

  }
}