package graphs;
import java.util.*;

class adjacency_list
{
	ArrayList<ArrayList<Integer>> adjlist=new ArrayList<> ();
	
	adjacency_list(int numvertex)
	{
		for(int i=0;i<numvertex;i++)
		{
			adjlist.add(new ArrayList<Integer>());
		}
	}
	
	void addedge(int v1,int v2)
	{
		adjlist.get(v1).add(v2);
	}
	
	void print()
	{
		for(int i=0;i<adjlist.size();i++)
		{
	     
	      for(int j=0;j<adjlist.get(i).size();j++)
	      {
		      System.out.println("vertex:"+i +  "edges" + adjlist.get(i).get(j));

	      }
		}
	}
	
	
}

public class adjacent_list 
{
  public static void main(String args[])
  {
	  adjacency_list x=new adjacency_list(5);
	  x.addedge(2, 1);
	  x.addedge(1, 4);
	  x.addedge(3, 2);
	  x.addedge(4, 1);
	  x.addedge(2, 1);

	  x.print();

  }
}
