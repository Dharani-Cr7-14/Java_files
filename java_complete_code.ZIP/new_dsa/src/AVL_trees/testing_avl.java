package AVL_trees;

class avl
{
	node root;
	
	avl(int val)
	{
		root=new node(val);
	}
	avl()
	{
		root=null;
	}
	class node
	{
	  int val;
	  node left;
	  node right;
	  int height;
	  
	  node(int val)
	  {
		  this.val=val;
	  }
	}
	
	int height(node root)
	{
		if(root==null)
		{
			return -1;
		}
		else
		{
			return root.height;
		}
	}
	
	int max(int a,int b)
	{
		return a>b?a:b;
	}
	
	int balancefactor(node root)
	{
		if(root==null)
		{
			return 1;
		}
		else
		{
          return height(root.left)-height(root.right);
		}
	}
	void insert(int val)
	{
		
		insert(root,val);
	}
	node insert(node root,int val)
	{
		if(root==null)
		{
			return new node(val);
		}
		else if(val<root.val)
		{
			root.left=insert(root.left,val);
		}
		else if(val>root.val)
		{
			root.right=insert(root.right,val);
		}
		else
		{
			return root;
		}
		int bal_factor=balancefactor(root);
		if(bal_factor >1 && val <root.left.val)
		{
			return rightrotate(root);
		}
		if(bal_factor > 1 && val>root.left.val)
		{
			root.left=leftrotate(root);
			return rightrotate(root);
		}
		if(bal_factor <-1 && val > root.right.val)
		{
			return leftrotate(root);
		}
		if(bal_factor <-1 && val<root.right.val)
		{
			root.right= rightrotate(root);
			return leftrotate(root);
		}
		
		return root;
	}
	
	node rightrotate(node z)
	{
		node y=z.left;
		node t3=y.right;
		
		y.right=z;
		z.left=t3;
		
		z.height=1+max(height(z.left),height(z.right));
		y.height=1+max(height(z.left),height(z.right));
        
		return y;
	}
	
	node leftrotate(node z)
	{
		node y=z.right;
		node t3=y.left;
		
		y.left=z;
		z.right=t3;
		
		z.height=1+max(height(z.left),height(z.right));
		y.height=1+max(height(z.left),height(z.right));
		return y;

	}
	 void inorder(node root)
	    {
	    	if(root!=null)
	    	{
	    		inorder(root.left);
	    		System.out.println(root.val);
	    		inorder(root.right);
	    	}
	    }
	
	
}

public class testing_avl
{
 public static void main(String args[])
 {
	 avl x=new avl(30);
	 x.insert(2);
	 x.insert(37);
	 x.insert(7);
	 x.insert(44);
	 x.insert(9);
	 x.inorder(x.root);
 }
}
