package AVL_trees;



class AVL
{
	node root;
	
	AVL(int val)
	{
		root=new node(val);
	}
	AVL()
	{
		root=null;
	}
	class node
	{
		int val;
		int height;
		node left;
		node right;
		
		node(int val)
		{
			this.val=val;
			
		}
	}
	
	int getheight(node root)
	{
		 if(root==null)
		 {
			 return -1;
			 
		 }
		 return root.height;
     }
	int max(int a,int b)
	{
		return a>b?a:b;
	}
	int balancefactor(node root)
	{
		if(root==null)
		{
			return 0;
		}
		return getheight(root.left)-getheight(root.right);
	}
	
	void insert(int val)
	{
		root=insert(root,val);
	}
    node insert(node root,int val)
	{
		if(root==null)
		{
			return new node(val);
		}
		
		if(val<root.val)
		{
           root.left=insert(root.left,val);
		}
		else if(val>root.val)
		{
			root.right=insert(root.right,val);
		}
		else
		{
			return root;
		}
	    
        int balfactor=balancefactor(root);
        
        if(balfactor>1 && val <root.left.val) //ll
        {
           return rightrotate(root);	
        }
        if(balfactor>1 && val >root.left.val) //lr
        {
        	root.left=leftrotate(root);
        	return rightrotate(root);
        	
        }
        if(balfactor<-1 && val >root.right.val) //rr
        {
        	return leftrotate(root);
        }
        if(balfactor<-1 && val <root.right.val) //rl
        {
        	root.right=rightrotate(root);
        	return leftrotate(root);
        }
	        
		return root;
		
	}
    node rightrotate(node z)
    {
    	 node y=z.left;
    	 node t3=y.right;
    	 
    	 y.right=z;
    	 z.left=t3;
    	 
    	 z.height=1+max(getheight(z.left),getheight(z.right));
    	 y.height=1+max(getheight(z.left),getheight(z.right));
    	 return y;
    }
    
    node leftrotate(node z)
    {
    	node y=z.right;
    	node t3=y.left;
    	
    	y.right=z;
    	z.left=t3;
    	
    	z.height=1+max(getheight(z.left),getheight(z.right));
   	    y.height=1+max(getheight(z.left),getheight(z.right));
    	return y;
    }
	
    void inorder(node root)
    {
    	if(root!=null)
    	{
    		inorder(root.left);
    		System.out.println(root.val);
    		inorder(root.right);
    	}
    }
}

public class avl_treees
{
	public static void main(String args[])
	{
		AVL li=new  AVL (50);
		li.insert(5);
		li.insert(3);
		li.insert(2);
		li.insert(37);
		li.insert(7);
		li.insert(44);
		li.insert(9);
		li.inorder(li.root);
		
		
	}
}
