package Queue;

class queue
{
	int arr[]=new int[31];
	int front=0;
	int rear=-1;
	
	
	void enqueue(int val)
	{
		                           //  queue implementation and circular queue......
		arr[++rear]=val;
	}
	
	
	
	void dequeue()
	{
		
		int temp=arr[front++];
		System.out.println(temp);
		
		/* int temp=arr[0];
		for(int i=1;i<=rear;i++)
		{
			arr[i-1]=arr[i];
			
		}
		rear--;  */
		
	}
	
	
}

public class Queue_Arr 
{
	public static void main(String args[])
	{
		queue obj=new queue();
		obj.enqueue(1);
		obj.enqueue(2);
		obj.enqueue(3);
		//obj.enqueue(4);
		obj.dequeue();
		obj.dequeue();
	/*	System.out.println(obj.dequeue());
		System.out.println(obj.dequeue());

		
		System.out.println(obj.dequeue());
		System.out.println(obj.dequeue()); */
	}

}
