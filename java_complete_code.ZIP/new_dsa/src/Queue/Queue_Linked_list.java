package Queue;

class queue_ll
{
	node head;
	node front;
	node rearr;   // for testing 
	int rear=-1;
	
	queue_ll()
	{
		front=null;
		this.rearr=null;
	}

	
	void enqueue(int val)
	{
		node newnode=new node(val);

		if(rear==-1)
		{
			head=newnode;
			rear++;
			
		}
		else
		{
			node temp=head;
			for(int i=0;i<rear;i++)
			{
				temp=temp.next;
			}
			temp.next=newnode;
			rear++;
		}
				
	}
	int  dequeue()
	{
		int  temp=head.val;
		head=head.next;
		
		return temp;
	}
	
	   void enqueue2(int val)
	{
		node newnode=new node(val);
		{
			if(front==null)
			{                         //    just try not working
				front=newnode;
				rearr=newnode;
			}
			else
			{
				
				rearr.next=newnode;
			    rearr=newnode;
			}
		}
		
		
	}     
	
	
	  int dequeue2()
	{
		int temp=front.val;    //  just try not working
		front=front.next;
		return temp;
	}    
	class node
	{
		int val;
		node next;
		
		node(int val)
		{
			this.val=val;
			next=null;
		}
	}
}

public class Queue_Linked_list 
{
	public static void main(String args[])
	{
		queue_ll obj=new queue_ll();
		obj.enqueue(1);
		obj.enqueue(2);
		obj.enqueue(3);
		obj.enqueue(4);
		System.out.println(obj.dequeue());
		System.out.println(obj.dequeue());
		System.out.println(obj.dequeue()); 
		System.out.println(obj.dequeue());
		obj.enqueue(3);
		obj.enqueue(4);
		System.out.println(obj.dequeue());
		System.out.println(obj.dequeue());
	}
}
