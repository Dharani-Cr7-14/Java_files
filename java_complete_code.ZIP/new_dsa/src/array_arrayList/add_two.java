package array_arrayList;
class adding 
{
	static void add(int arr[],int target)
	{
		for(int i=0;i<arr.length;i++)
		{
			for(int j=0;j<arr.length;j++)
			{
				if(arr[i]+arr[j]==target)
				{
					System.out.print("crt");
				}
			}
		}
	}
}

public class add_two
{
	public static void main(String args[])
	  {
		  int arr[]= {1,2,3,4,5};
		  adding.add(arr,4);
     }
}
