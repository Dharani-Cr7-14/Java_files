package array_arrayList;

import java.util.*;

class maxing
{
	static int max(int arr[])
	{
		int max=arr[0];
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]>max)
			{
				max=arr[i];
			}
		}return max;
	}
}

public class max_arr
{
	public static void main(String args[])
	  {
		
		  Scanner scan=new Scanner(System.in);
		  int arr[]=new int[3];
		  
		  for(int i=0;i<arr.length;i++)
		  {
			  arr[i]=scan.nextInt();
		  }
		  
		 System.out.println( maxing.max(arr));
	  }  

}
