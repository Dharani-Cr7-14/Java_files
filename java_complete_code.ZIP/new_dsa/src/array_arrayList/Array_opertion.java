package array_arrayList;
import java.util.*;

class arrays
{
	static int arr[]=new int [4];
	static int size=0;
	static int cap=4;
	static Scanner scan=new Scanner(System.in);

	static void add()
	{
		expandArr();
			arr[size]=scan.nextInt();
			size++;
		
		System.out.println(size);
	}
	static void dis()
	{

		for(int i=0;i<size;i++)
		{
			System.out.println(arr[i]);
		}
	}
	
			
		 static private void expandArr()
		{
			cap*=2;
			arr=java.util.Arrays.copyOf(arr,cap);
		}
		
	
	static void ins(int val,int pos)
	{

		
		for(int i=arr.length-1;i>=pos;i--)
		{
			expandArr();
			arr[i+1]=arr[i];
			
		}
		arr[pos]=arr[val];
		size++;
	}
	
}

public class Array_opertion 
{
	public static void main(String args[])
	{
		
		
		arrays.add();
		//arrays.dis();
		arrays.add();

		arrays.add();
		arrays.add();



		
		arrays.ins( 23, 2);
		arrays.dis();


		
		
	}

}
