package array_arrayList;

import java.util.Arrays;

class kTh
{
	static void find(int arr[],int k)
	{
     Arrays.sort(arr);
	 System.out.println(Arrays.toString(arr));
	 for(int i=0;i<arr.length;i++)
	 {
		 if(arr[i]==((arr.length+1)-k))
		 {
			 System.out.println(arr[i]);
		 }
	 }
	}
}

public class kTH_large
{
	public static void main(String args[])
	  {
		  int arr[]= {5,2,6,1,4,3};
		 
		  kTh.find(arr,2);
   }

}
