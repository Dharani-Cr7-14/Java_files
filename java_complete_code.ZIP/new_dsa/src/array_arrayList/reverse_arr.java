package array_arrayList;

import java.util.Arrays;
import java.util.Scanner;

class reverse
{
	static void rev(int arr[])
	{
		int start=0;
		int end=arr.length-1;
		while(start<end)
		{
			int temp=arr[start];
			arr[start]=arr[end];
			arr[end]=temp;
			start++;
			end--;
		}
	}
	
}

public class reverse_arr
{
	public static void main(String args[])
	  {
		
		  Scanner scan=new Scanner(System.in);
		  int arr[]=new int[6];
		  
		  for(int i=0;i<arr.length;i++)
		  {
			  arr[i]=scan.nextInt();
		  }
		  reverse.rev(arr);
		  System.out.println(Arrays.toString(arr));
	  }
}
