package array_arrayList;
import java.util.*;

class array
{
	int start=0;
	int capacity=5;
	int arr[]=new int[capacity];
	Scanner scan=new Scanner(System.in);

	
	void insert()
	{
		if(start==capacity)
		{
			expand();
			System.out.println("cap full Lets expand....");
		}
		arr[start++]=scan.nextInt();
		 
		
		
	}
	
	
	void display()
	{
		for(int i=0;i<start;i++)
		{
			System.out.println(arr[i]);

		}
		
	}
	
	void expand()
	{
		capacity*=2;
		arr=Arrays.copyOf(arr, capacity);
	}
	void start()
	{
		System.out.println("the start val after add :"+start);
	}
	
	void InserAtPos(int pos,int val)
	{
		expand();
		for(int i=start-1;i>=pos;i--)
		{
		   arr[i+1]=arr[i];		
				
		}
		arr[pos]=val;
		start++;					
	}
	void delectAtPos(int pos)
	
	{
		
		for(int i=pos+1;i<start;i++)
		{
			arr[i-1]=arr[i];
			
		}
		start--;
		
	}
void delectAtPos()
	
	{
		
		for(int i=1;i<start;i++)
		{
			arr[i-1]=arr[i];
			
		}
		start--;
		
	}

	
}



public class Arr_OP_2 
{
 public static void main(String args[])
 {
	 array obj=new array();
	 Scanner scan=new Scanner(System.in);
	
	 while(true)
	 {
		 System.out.println("enter the op you need to do");
		int x=scan.nextInt();
		switch(x)
		{
		case 1:
			 System.out.println("enter the valueee");

			 obj.insert();
			 break;
		case 2:
			
			 obj.display();
			
			obj.start();
			 break;
		case 3:
			obj.InserAtPos(2, 111);
			break;
		case 4:
			obj.delectAtPos();
		    break;
	     }   
	 
	

     }
}
}
