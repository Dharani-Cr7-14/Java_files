package array_arrayList;
import java.util.*;

public class MutiDim_arr
{
  public static void main(String args[])
  {
	  Scanner scan =new Scanner(System.in);
	  ArrayList<ArrayList<Integer>> list=new ArrayList<>();
	  
	  for(int i=0;i<3;i++)     // need to initialize to fix the size
	  {
		  list.add(new ArrayList<>());
	  }
	  
	  for(int i=0;i<3;i++)    // input
	  {
		  for(int j=0;j<3;j++)
		  {
				list.get(i).add(scan.nextInt());

		  }
	  }

	  for(int i=0;i<3;i++)      // printing 
	  {
		 System.out.println( list.get(i));
	  }
	  
  }
}
