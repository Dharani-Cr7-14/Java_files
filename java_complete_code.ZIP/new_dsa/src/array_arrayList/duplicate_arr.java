package array_arrayList;

import java.util.Scanner;


class duplicate
{
	static void dup(int arr[])    
	{
		int j=0;
		for(int i=0;i<arr.length-1;i++)
		{
			if(arr[i]!=arr[i+1])
			{
				arr[j++]=arr[i];
				
			}
		}
		
		arr[j++]=arr[arr.length-1];
		for(int k=0;k<j;k++)
			{
				System.out.println(arr[k]);
			}
		}
	}



public class duplicate_arr
{
	public static void main(String args[])
		  {
			  int arr[]= {1,1,1,2,2,4,4,4,7,7,7,7,8,8,9};
			  duplicate.dup(arr);
	       }
}
