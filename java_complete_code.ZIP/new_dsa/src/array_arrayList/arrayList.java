package array_arrayList;
import java.util.*;

public class arrayList 
{
  public static void main(String args[])
  {
	  Scanner scan=new Scanner(System.in);

	  ArrayList<Integer> list=new ArrayList<>();
	  
	
	  for(int i=0;i<3;i++)
	  {
		 list.add(scan.nextInt());
	  }
	  
	  for(int i=0;i<3;i++)
	  System.out.println(list.get(i));

	  
	  
  }

private static Integer nextInt() {
	// TODO Auto-generated method stub
	return null;
}
}
