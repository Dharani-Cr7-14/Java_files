package array_arrayList;

import java.util.Arrays;

class sec_lar
{
/*	static int  sec(int arr[])
	{
		int max=arr[0];
		int second=-1;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]>max)
			{
				second=max;
				max=arr[i];
			}
			else if (arr[i]<max && arr[i]>second)
			{
				second=arr[i];
			}
		}return second;
	}*/
	
	
	
	static int min(int arr[])
	{
		int min=arr[0];
		int second=Integer.MAX_VALUE;;
		
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]<min)
			{
				second=min;
				min=arr[i];
			}
			else if(arr[i]!=min && arr[i]<second)
			{
				second=arr[i];
			}
			
		}return second;
		
	}
	static boolean sort(int arr[])
	{
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]>=arr[i-1])
			{
				
			}
			else
				return false;
		}return true;
	}
	
	
	
	
	static void dup(int arr[])    
	{
		int j=0;
		for(int i=0;i<arr.length-1;i++)
		{
			if(arr[i]!=arr[i+1])
			{
				arr[j++]=arr[i];
				
			}
		}
		
		arr[j++]=arr[arr.length-1];
		for(int k=0;k<j;k++)
			{
				System.out.println(arr[k]);
			}
		}
	}
		


public class secLarg_arrr
{
  public static void main(String args[])
  {
	  int arr[]= {1,1,1,2,2,4,4,4,7,7,7,7,8,8,9};
	  sec_lar.min(arr);
	 System.out.println(Arrays.toString(arr));
	  
  }
}
