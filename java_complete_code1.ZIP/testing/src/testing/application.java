package testing;
import java.util.*; 



class Employee { 

    String empName; 

    int empId; 

    String address; 

    String mailId; 

    String mobileNo; 

    double basicPay; 

 

    Employee(String empName, int empId, String address, String mailId, String mobileNo, double basicPay) { 

        this.empName = empName; 

        this.empId = empId; 

        this.address = address; 

        this.mailId = mailId; 

        this.mobileNo = mobileNo; 

        this.basicPay = basicPay; 

    } 

     

    void salarySlip(){ 

        double da = 0.97*basicPay; 

        double hra = 0.10*basicPay; 

        double pf = 0.12*basicPay; 

        double staffClub = 0.001*basicPay; 

        double grossSalary = basicPay + da + hra; 

        double netSalary = grossSalary - pf - staffClub; 

         

        System.out.println("Employee Name : "+empName); 

        System.out.println("Employee ID : "+empId); 

        System.out.println("Address : "+address); 

        System.out.println("MaiId : "+mailId); 

        System.out.println("MobilNo : "+mobileNo); 

        System.out.println("Basic pay : "+basicPay); 

        System.out.println("DA : "+da); 

        System.out.println("HRA : "+hra); 

        System.out.println("PF : "+pf); 

        System.out.println("staffClub : "+staffClub); 

        System.out.println("Gross salary : "+grossSalary); 

        System.out.println("Net salary : "+netSalary); 

    } 

} 

 

class Programmer extends Employee { 

    Programmer(String empName, int empId, String address, String mailId, String mobileNo, double basicPay) { 

        super(empName, empId, address, mailId, mobileNo, basicPay); 

    } 

} 

 

class AssistantProfessor extends Employee { 

    AssistantProfessor(String empName, int empId, String address, String mailId, String mobileNo, double basicPay) { 

        super(empName, empId, address, mailId, mobileNo, basicPay); 

    } 

} 

 

class AssociateProfessor extends Employee { 

    AssociateProfessor(String empName, int empId, String address, String mailId, String mobileNo, double basicPay) { 

        super(empName, empId, address, mailId, mobileNo, basicPay); 

    } 

} 

 

class Professor extends Employee { 

    Professor(String empName, int empId, String address, String mailId, String mobileNo, double basicPay) { 

        super(empName, empId, address, mailId, mobileNo, basicPay); 

    } 

} 

 



public class application
{
	public static void main(String[] args) { 

        Programmer programmer = new Programmer("John Doe", 101, "123 Main St", "john.doe@example.com", "1234567890", 50000); 

        AssistantProfessor assistantProfessor = new AssistantProfessor("Jane Smith", 102, "456 Elm St", "jane.smith@example.com", "0987654321", 60000); 

        AssociateProfessor associateProfessor = new AssociateProfessor("Jim Brown", 103, "789 Oak St", "jim.brown@example.com", "1122334455", 70000); 

        Professor professor = new Professor("Jake White", 104, "101 Pine St", "jake.white@example.com", "6677889900", 80000); 

 

        System.out.println("Programmer Pay Slip:"); 

        programmer.salarySlip(); 

        System.out.println("\nAssistant Professor Pay Slip:"); 

        assistantProfessor.salarySlip(); 

        System.out.println("\nAssociate Professor Pay Slip:"); 

        associateProfessor.salarySlip(); 

        System.out.println("\nProfessor Pay Slip:"); 

        professor.salarySlip(); 

    } 

}
