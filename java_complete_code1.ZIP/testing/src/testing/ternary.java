package testing;

public class ternary 
{
    public static void main(String[] args){ 

        int a=10; 

        int b=20; 

        String c; 

       c=(a>b)?"b is big":"a is big"; 

       System.out.println(c); 

} 
}
