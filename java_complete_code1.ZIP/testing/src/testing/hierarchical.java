package testing;

class Vehicle { 

    void start() { 

        System.out.println("Vehicle is starting..."); 

    } 

} 

class ElectricCar extends Vehicle { 

    void charge() { 

        System.out.println("Electric car is charging..."); 

    } 

} 

class Bike extends Vehicle { 

    void kickStart() { 

        System.out.println("Bike is kick-starting..."); 

    }


} 



public class hierarchical {
	 public static void main(String[] args) { 

	        ElectricCar E = new ElectricCar(); 

	        E.charge();  

	        E.start(); 
	     

	        System.out.println(""); 

	        Bike B = new Bike(); 

	        B.kickStart(); 
            B.charge();
	        B.start(); 

	    } 
}
