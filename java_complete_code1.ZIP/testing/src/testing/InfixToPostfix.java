package testing;


import java.util.Stack;

public class InfixToPostfix {

    // Function to return precedence of operators
    private static int precedence(char c) {
        if (c == '+' || c == '-') return 1;
        if (c == '*' || c == '/') return 2;
        if (c == '^') return 3;
        return 0;
    }

    // Function to convert infix to postfix
    public static String infixToPostfix(String infix) {
        Stack<Character> stack = new Stack<>();
        StringBuilder postfix = new StringBuilder();
        
        // Use a normal for loop instead of enhanced for loop
        for (int i = 0; i < infix.length(); i++) {
            char c = infix.charAt(i);
            
            // If character is an operand (a letter or digit), add to result
            if (Character.isLetterOrDigit(c)) {
                postfix.append(c);
            }
            // If character is '(', push to stack
            else if (c == '(') {
                stack.push(c);
            }
            // If character is ')', pop until '(' is found
            else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    postfix.append(stack.pop());
                }
                stack.pop();  // Remove '(' from stack                         
            }
            // If character is an operator, check precedence and handle
            else {
                while (!stack.isEmpty() && precedence(stack.peek()) >= precedence(c)) {
                    postfix.append(stack.pop());
                }
                stack.push(c);
            }
        }
        
        // Pop any remaining operators from stack
        while (!stack.isEmpty()) {
            postfix.append(stack.pop());
        }
        
        return postfix.toString();
    }

    public static void main(String[] args) {
        String infix = "a+b*(c+d-e)+(f+g*h)-i";
        System.out.println("Infix: " + infix);
        System.out.println("Postfix: " + infixToPostfix(infix));
    }
}
