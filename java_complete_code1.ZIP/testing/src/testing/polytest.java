package testing;

import java.util.*;

class poly
{
	node head;
	class node
	{
		 int coeff;
		 int expo;
		 node next;
		 node(int coeff,int expo)
		 {
			 this.coeff=coeff;
			 this.expo=expo;
			 next=null;
		 }
	}
	
	void insert(int coeff,int expo)                                                                                                                                                                                                                                                                                                                                                                                                                                                   
	{
		node newnode=new node(coeff,expo);
		if(head==null || head.expo <expo)
		{
			newnode.next=head;
			head=newnode;
		}
		else
		{
			node temp=head;
			while(temp.next!=null && temp.next.expo>expo)
			{
				temp=temp.next;
			}
			if(temp.next!=null && temp.next.expo==expo)
			{
				temp.next.coeff+=coeff;
			}
			else
			{
				newnode.next=temp.next;
				temp.next=newnode;
			}
		}
	}
	 void display()
	 {
		 node temp=head;
		 while(temp!=null)
		 {
			 if(temp.coeff>0 && temp!=head)
			 {
				 System.out.print("+");
			 }
			 if(temp.expo==0)
			 {
				 System.out.print(temp.coeff);

			 }
			 else if(temp.expo==1)
			 {
				 System.out.print(temp.coeff +"x");

			 }
			 else
			 {
				 System.out.print(temp.coeff +"x^"+ temp.expo);

			 }
			 temp=temp.next;
		 }
		 
	 }
}

public class polytest
{
	 public static void main(String[] args) 
	 {
	        Scanner scanner = new Scanner(System.in);
	        poly p1=new poly();
	        poly p2=new poly();
	        int coeff,expo;
	        System.out.println("enter the no of term in polynomial:");
	        int term=scanner.nextInt();
	        
	        for(int i=0;i<term;i++)
	        {
		        System.out.println("enter the coefff:");
		        coeff=scanner.nextInt();
		        System.out.println("enter the expo:");
		        expo=scanner.nextInt();
		        p1.insert(coeff, expo);
	
	        }
	        p1.display();
	        
	 }
}
