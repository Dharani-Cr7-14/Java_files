package testing;

import java.util.Scanner;

class Node {
    int coeff;
    int expo;
    Node next;

    public Node(int coeff, int expo) {
        this.coeff = coeff;
        this.expo = expo;
        this.next = null;
    }
}

class Polynomial {
    Node head;

    public void insertTerm(int coeff, int expo) {
        Node newNode = new Node(coeff, expo);

        if (head == null || head.expo < expo) {
            newNode.next = head;
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null && temp.next.expo > expo) {
                temp = temp.next;
            }

            if (temp.next != null && temp.next.expo == expo) {
                temp.next.coeff += coeff;
            } else {
                newNode.next = temp.next;
                temp.next = newNode;
            }
        }
    }

    public void display() {
        Node temp = head;
        while (temp != null) {
            if (temp.coeff > 0 && temp != head) {
                System.out.print("+");
            }
            if (temp.expo == 0) {
                System.out.print(temp.coeff);
            } else if (temp.expo == 1) {
                System.out.print(temp.coeff + "x");
            } else {
                System.out.print(temp.coeff + "x^" + temp.expo);
            }
            temp = temp.next;
        }
        System.out.println();
    }

    public Polynomial add(Polynomial poly) {
        Polynomial result = new Polynomial();
        Node p1 = this.head;
        Node p2 = poly.head;

        while (p1 != null || p2 != null) {
            if (p1 == null) {
                result.insertTerm(p2.coeff, p2.expo);
                p2 = p2.next;
            } else if (p2 == null) {
                result.insertTerm(p1.coeff, p1.expo);
                p1 = p1.next;
            } else if (p1.expo == p2.expo) {
                result.insertTerm(p1.coeff + p2.coeff, p1.expo);
                p1 = p1.next;
                p2 = p2.next;
            } else if (p1.expo > p2.expo) {
                result.insertTerm(p1.coeff, p1.expo);
                p1 = p1.next;
            } else {
                result.insertTerm(p2.coeff, p2.expo);
                p2 = p2.next;
            }
        }

        return result;
    }

    public Polynomial multiply(Polynomial poly) {
        Polynomial result = new Polynomial();
        Node p1 = this.head;

        while (p1 != null) {
            Node p2 = poly.head;
            while (p2 != null) {
                result.insertTerm(p1.coeff * p2.coeff, p1.expo + p2.expo);
                p2 = p2.next;
            }
            p1 = p1.next;
        }

        return result;
    }
}

public class PolynomialOperations {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Polynomial poly1 = new Polynomial();
        Polynomial poly2 = new Polynomial();

        System.out.print("Enter the number of terms for the first polynomial: ");
        int terms1 = scanner.nextInt();
        for (int i = 0; i < terms1; i++) {
            System.out.print("Enter coefficient: ");
            int coeff = scanner.nextInt();
            System.out.print("Enter exponent: ");
            int expo = scanner.nextInt();
            poly1.insertTerm(coeff, expo);
        }

        System.out.println("First Polynomial: ");
        poly1.display();

        System.out.print("Enter the number of terms for the second polynomial: ");
        int terms2 = scanner.nextInt();
        for (int i = 0; i < terms2; i++) {
            System.out.print("Enter coefficient: ");
            int coeff = scanner.nextInt();
            System.out.print("Enter exponent: ");
            int expo = scanner.nextInt();
            poly2.insertTerm(coeff, expo);
        }

        System.out.println("Second Polynomial: ");
        poly2.display();

        while (true) {
            System.out.println("Choose an option:");
            System.out.println("1) Add Polynomials");
            System.out.println("2) Multiply Polynomials");
            System.out.println("3) Exit");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    Polynomial sum = poly1.add(poly2);
                    System.out.println("Sum of Polynomials:");
                    sum.display();
                    break;
                case 2:
                    Polynomial product = poly1.multiply(poly2);
                    System.out.println("Product of Polynomials:");
                    product.display();
                    break;
                case 3:
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}