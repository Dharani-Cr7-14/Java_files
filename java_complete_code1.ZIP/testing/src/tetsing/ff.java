package tetsing;


class Node {
    int data;      // Data in the node
    Node next;     // Pointer to the next node

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedListQueue {
    Node front;    // Points to the first node
    Node rear;     // Points to the last node

    // Constructor
    LinkedListQueue() {
        this.front = null;
        this.rear = null;
    }

    // Add an element to the queue
    void enqueue(int value) {
        Node newNode = new Node(value); // Create a new node
        if (rear == null) {            // If queue is empty
            front = rear = newNode;    // Both front and rear point to the new node
        } else {
            rear.next = newNode;       // Link the new node at the rear
            rear = newNode;            // Update rear to the new node
        }
        System.out.println("Added: " + value);
    }

    // Remove an element from the queue
    int dequeue() {
        if (front == null) {           // If queue is empty
            System.out.println("Queue is empty!");
            return -1; // Sentinel value for empty queue
        }
        int value = front.data;        // Get the front node's data
        front = front.next;            // Move front to the next node
       
        System.out.println("Removed: " + value);
        return value;
    }

    // Peek the front element
    int peek() {
        if (front == null) {           // If queue is empty
            System.out.println("Queue is empty!");
            return -1;
        }
        return front.data;
    }

    // Display all elements in the queue
    void display() {
        Node temp=front;
        while(temp!=null)
        {
            System.out.println(temp.data);

        	temp=temp.next;
        }
        System.out.println();
    }
}

public class ff {
    public static void main(String[] args) {
        LinkedListQueue queue = new LinkedListQueue();

        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);

        queue.display();

        queue.dequeue();
        queue.dequeue();

        queue.display();

        System.out.println("Front: " + queue.peek());
    }
}
