package tetsing;

class CircularQueuew {
    int[] arr; // Array for storing elements
    int front; // Points to the front of the queue
    int rear;  // Points to the next available position
    int size;  // Current number of elements
    int capacity;

    // Constructor
    CircularQueuew(int capacity) {
        this.capacity = capacity;
        arr = new int[capacity];
        front = 0;
        rear = 0;
        size = 0;
    }

    // Add an element
    void enqueue(int value) {
        if (size == capacity) {
            System.out.println("Queue is full!");
            return;
        }
        arr[rear] = value;         // Add at rear
        rear = (rear + 1) % capacity; // Move rear forward (wrap around)
        size++;                   // Increase size
        System.out.println("Added: " + value);
    }

    // Remove an element
    int dequeue() {
        
        int value = arr[front];    // Get front element
        front = (front + 1) % capacity; // Move front forward (wrap around)
        size--;                   // Decrease size
        System.out.println("Removed: " + value);
        return value;
    }

    // Peek front element
    int peek() {
        if (size == 0) {
            System.out.println("Queue is empty!");
            return -1;
        }
        return arr[front];
    }

    // Display queue
    void display() {
        if (size == 0) {
            System.out.println("Queue is empty!");
            return;
        }
        System.out.print("Queue: ");
        for (int i = 0; i < size; i++) {
            System.out.print(arr[(front + i) % capacity] + " ");
        }
        System.out.println();
    }
}

public class CircularQueue  {
    public static void main(String[] args) {
        CircularQueuew queue = new CircularQueuew(5);

        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);
        queue.enqueue(40);
        queue.enqueue(50);
        queue.enqueue(60); // Queue is full

        queue.display();

        queue.dequeue();
        queue.dequeue();

        queue.display();
        queue.enqueue(60);
        queue.enqueue(60);
        System.out.println("Front: " + queue.peek());
    }
}
