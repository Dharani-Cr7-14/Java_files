package tetsing;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

// LinkedList Class
class LinkedList {
    static class Node {
        int val;
        Node next;

        public Node(int val) {
            this.val = val;
            this.next = null;
        }
    }

    // Method to insert a node at the end of the list
    public static Node insert(Node head, int val) {
        Node newNode = new Node(val);
        if (head == null) {
            return newNode;
        }
        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }
        temp.next = newNode;
        return head;
    }

    // Method to display the list
    public static void display(Node head) {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.val + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    // Method to create a union of two lists
    public static Node union(Node head1, Node head2) {
        Set<Integer> set = new HashSet<>();
        Node result = null;

        // Add elements from head1 to set
        while (head1 != null) {
            if (!set.contains(head1.val)) {
                result = insert(result, head1.val);
                set.add(head1.val);
            }
            head1 = head1.next;
        }

        // Add elements from head2 to set
        while (head2 != null) {
            if (!set.contains(head2.val)) {
                result = insert(result, head2.val);
                set.add(head2.val);
            }
            head2 = head2.next;
        }

        return result;
    }

    // Method to create an intersection of two lists
    public static Node intersection(Node head1, Node head2) {
        Set<Integer> set = new HashSet<>();
        Node result = null;

        // Store elements of head2 in a set
        while (head2 != null) {
            set.add(head2.val);
            head2 = head2.next;
        }

        // Add common elements from head1
        while (head1 != null) {
            if (set.contains(head1.val)) {
                result = insert(result, head1.val);
                set.remove(head1.val);  // Remove to avoid duplicates in the intersection
            }
            head1 = head1.next;
        }

        return result;
    }

    // Method to create the difference of two lists (head1 - head2)
    public static Node difference(Node head1, Node head2) {
        Set<Integer> set = new HashSet<>();
        Node result = null;

        // Store elements of head2 in a set
        while (head2 != null) {
            set.add(head2.val);
            head2 = head2.next;
        }

        // Add elements from head1 that are not in head2
        while (head1 != null) {
            if (!set.contains(head1.val)) {
                result = insert(result, head1.val);
            }
            head1 = head1.next;
        }

        return result;
    }
}

// Main Class
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedList.Node head1 = null, head2 = null;
        int val;

        // Input for List1
        System.out.print("Enter elements for List1 (Enter -1 to stop): ");
        while (true) {
            val = sc.nextInt();
            if (val == -1) break;
            head1 = LinkedList.insert(head1, val);
        }

        // Input for List2
        System.out.print("Enter elements for List2 (Enter -1 to stop): ");
        while (true) {
            val = sc.nextInt();
            if (val == -1) break;
            head2 = LinkedList.insert(head2, val);
        }

        // Print Union of List1 and List2
        LinkedList.Node unionList = LinkedList.union(head1, head2);
        System.out.print("Union of List1 and List2: ");
        LinkedList.display(unionList);

        // Print Intersection of List1 and List2
        LinkedList.Node intersectionList = LinkedList.intersection(head1, head2);
        System.out.print("Intersection of List1 and List2: ");
        LinkedList.display(intersectionList);

        // Print Difference of List1 - List2
        LinkedList.Node differenceList = LinkedList.difference(head1, head2);
        System.out.print("Difference of List1 and List2: ");
        LinkedList.display(differenceList);

        sc.close();
    }
}
